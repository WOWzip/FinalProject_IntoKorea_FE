

// // module.exports = {
// //     user :process.env.NODE_ORACLEDB_USER || "dbtest",
// //     password : process.env.NODE_ORACLEDB_PASSWORD || "a1234",
// //     connectString : process.env.NODE_ORACLEDB_CONNECTIONSTRING || "localhost:1521/xe",
// //     externalAuth : process.env.NODE_ORACLEDB_EXTERNALAUTH ? true : false
// // }


// module.exports = {
//     user :"dbtest",
//     password :"a1234",
//     connectString :"localhost:1521/xe",
//     externalAuth :false
// }