

// tourCategory.jsx

import styled from "styled-components";




const TourCategory = () =>  {


    return (
        <>
        
        </>
    )
}

export default TourCategory;