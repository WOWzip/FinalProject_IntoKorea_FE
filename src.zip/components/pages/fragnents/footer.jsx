


function Footer(props){
    return(
        <>
            <h1>푸터입니다.</h1>
        </>
    )
}


export default Footer;